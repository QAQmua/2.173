// 📄 完整替换文件：信息/MessagesChatDetailView.swift
import SwiftUI
import PhotosUI
import AudioToolbox
import UniformTypeIdentifiers

@MainActor
struct MessagesChatDetailView: View {
    let conversationID: String
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @Environment(\.colorScheme) private var colorScheme
    
    @AppStorage private var selectedSendSoundID: Int
    @AppStorage private var selectedReceiveSoundID: Int
    @AppStorage private var customBubbleColorHex: String
    @AppStorage private var customTextColorHex: String
    @AppStorage private var customPeerBubbleColorHex: String
    @AppStorage private var customPeerTextColorHex: String
    @AppStorage private var customSendButtonColorHex: String
    @AppStorage private var bgImageID: String
    @AppStorage private var chatFontSize: Double
    @AppStorage private var enableIOS27BubbleGradient: Bool
    @AppStorage private var showReceipts: Bool
    @AppStorage private var showTypingIndicator: Bool
    
    @AppStorage private var customSendAudioFile: String
    @AppStorage private var customSendAudioName: String
    @AppStorage private var customReceiveAudioFile: String
    @AppStorage private var customReceiveAudioName: String
    
    @State private var inputText: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var avatarPhotoItem: PhotosPickerItem? = nil
    @State private var replyingToMessage: IMMessageItem? = nil
    @State private var showSendEffectSheet: Bool = false
    @State private var showContactInfoSheet: Bool = false
    @State private var revealedInvisibleIDs: Set<String> = []
    @FocusState private var isInputFocused: Bool
    
    @State private var isSelectionMode: Bool = false
    @State private var selectedMessageIDs: Set<String> = []
    @State private var showClearAllConfirm: Bool = false
    
    init(conversationID: String) {
        self.conversationID = conversationID
        self._selectedSendSoundID = AppStorage(wrappedValue: 1004, "chat_send_sound_\(conversationID)")
        self._selectedReceiveSoundID = AppStorage(wrappedValue: 1005, "chat_receive_sound_\(conversationID)")
        self._customBubbleColorHex = AppStorage(wrappedValue: "", "chat_bubble_color_\(conversationID)")
        self._customTextColorHex = AppStorage(wrappedValue: "", "chat_text_color_\(conversationID)")
        self._customPeerBubbleColorHex = AppStorage(wrappedValue: "", "chat_peer_bubble_color_\(conversationID)")
        self._customPeerTextColorHex = AppStorage(wrappedValue: "", "chat_peer_text_color_\(conversationID)")
        self._customSendButtonColorHex = AppStorage(wrappedValue: "", "chat_send_btn_color_\(conversationID)")
        self._bgImageID = AppStorage(wrappedValue: "", "chat_bg_image_\(conversationID)")
        self._chatFontSize = AppStorage(wrappedValue: 16.5, "chat_font_size_\(conversationID)")
        self._enableIOS27BubbleGradient = AppStorage(wrappedValue: true, "chat_ios27_grad_\(conversationID)")
        self._showReceipts = AppStorage(wrappedValue: true, "chat_show_receipts_\(conversationID)")
        self._showTypingIndicator = AppStorage(wrappedValue: true, "chat_show_typing_\(conversationID)")
        
        self._customSendAudioFile = AppStorage(wrappedValue: "", "chat_send_custom_audio_\(conversationID)")
        self._customSendAudioName = AppStorage(wrappedValue: "", "chat_send_custom_audio_name_\(conversationID)")
        self._customReceiveAudioFile = AppStorage(wrappedValue: "", "chat_receive_custom_audio_\(conversationID)")
        self._customReceiveAudioName = AppStorage(wrappedValue: "", "chat_receive_custom_audio_name_\(conversationID)")
    }
    
    private var conversation: IMConversation? {
        viewModel.conversations.first(where: { $0.id == conversationID })
    }
    
    private var isPeerTyping: Bool {
        guard let conv = conversation else { return false }
        let norm = MessagesNetworkEngine.normalizeID(conv.peerID)
        return viewModel.peerTypingMap[norm] ?? false
    }
    
    var body: some View {
        let s = uiScale
        ZStack {
            chatBackgroundView
            chatScrollSection(s: s)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if isSelectionMode {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                            isSelectionMode = false
                            selectedMessageIDs.removeAll()
                        }
                    }
                    .font(.system(size: 17 * s, weight: .bold))
                }
            } else {
                if #available(iOS 26.0, *) {
                    ToolbarItem(placement: .principal) {
                        principalHeaderItem
                    }
                    .sharedBackgroundVisibility(.hidden)
                } else {
                    ToolbarItem(placement: .principal) {
                        principalHeaderItem
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showContactInfoSheet = true
                    } label: {
                        Image(systemName: "video")
                    }
                }
            }
        }
        .confirmationDialog("使用特效发送", isPresented: $showSendEffectSheet, titleVisibility: .visible) {
            Button("震撼 (Slam)") { commitSend(effect: "slam") }
            Button("响亮 (Loud)") { commitSend(effect: "loud") }
            Button("轻柔 (Gentle)") { commitSend(effect: "gentle") }
            Button("隐形墨水 (刮开可见)") { commitSend(effect: "invisible") }
            Button("取消", role: .cancel) {}
        }
        .confirmationDialog("确定要清空该会话所有聊天记录吗？", isPresented: $showClearAllConfirm, titleVisibility: .visible) {
            Button("全部删除", role: .destructive) {
                clearAllMessages()
            }
            Button("取消", role: .cancel) {}
        }
        .sheet(isPresented: $showContactInfoSheet) {
            if let conv = conversation {
                NativeContactDetailSheet(
                    conversation: conv,
                    avatarPhotoItem: $avatarPhotoItem,
                    selectedSendSoundID: $selectedSendSoundID,
                    selectedReceiveSoundID: $selectedReceiveSoundID,
                    customBubbleColorHex: $customBubbleColorHex,
                    customTextColorHex: $customTextColorHex,
                    customPeerBubbleColorHex: $customPeerBubbleColorHex,
                    customPeerTextColorHex: $customPeerTextColorHex,
                    customSendButtonColorHex: $customSendButtonColorHex,
                    bgImageID: $bgImageID,
                    chatFontSize: $chatFontSize,
                    enableIOS27BubbleGradient: $enableIOS27BubbleGradient,
                    showReceipts: $showReceipts,
                    showTypingIndicator: $showTypingIndicator,
                    customSendAudioFile: $customSendAudioFile,
                    customSendAudioName: $customSendAudioName,
                    customReceiveAudioFile: $customReceiveAudioFile,
                    customReceiveAudioName: $customReceiveAudioName,
                    onClearAll: {
                        clearAllMessages()
                    }
                )
                .presentationDetents([.medium, .large])
            }
        }
        .task(id: selectedPhotoItem) {
            if let item = selectedPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self) {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                    viewModel.sendMessage(in: conversationID, text: "", imageData: data, replyTo: replyingToMessage)
                }
                replyingToMessage = nil
                selectedPhotoItem = nil
            }
        }
        .task(id: avatarPhotoItem) {
            if let item = avatarPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self),
               let idx = viewModel.conversations.firstIndex(where: { $0.id == conversationID }) {
                viewModel.conversations[idx].avatarImageID = LocalImageStore.shared.save(data: data)
                viewModel.saveConversations()
                avatarPhotoItem = nil
            }
        }
        .onChange(of: inputText) { _, newValue in
            guard let conv = conversation, !conv.isAIContact && !conv.isSMSChannel else { return }
            viewModel.sendTypingStatus(to: conv.peerID, isTyping: !newValue.isEmpty)
        }
    }
    
    @ViewBuilder
    private var chatBackgroundView: some View {
        (colorScheme == .dark ? Color(hex: "#010001") : Color(UIColor.systemBackground))
            .ignoresSafeArea()
        
        if !bgImageID.isEmpty,
           let data = LocalImageStore.shared.load(id: bgImageID),
           let uiImg = ImageBitmapCache.shared.image(from: data) {
            Image(uiImage: uiImg)
                .resizable()
                .scaledToFill()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(colorScheme == .dark ? 0.35 : 0.08))
        }
    }
    
    @ViewBuilder
    private func chatScrollSection(s: CGFloat) -> some View {
        let peerBubbleCol: Color? = customPeerBubbleColorHex.isEmpty ? nil : Color(hex: customPeerBubbleColorHex)
        let peerTextCol: Color? = customPeerTextColorHex.isEmpty ? nil : Color(hex: customPeerTextColorHex)
        let fontRatio: CGFloat = CGFloat(chatFontSize) / 16.5
        
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 0) {
                    LazyVStack(spacing: 0) {
                        if let conv = conversation {
                            let msgs = conv.messages
                            
                            if !msgs.isEmpty {
                                VStack(spacing: 3 * s) {
                                    Text(conv.isSMSChannel ? "信息 · 短信" : "iMessage信息")
                                        .font(.system(size: 11 * s, weight: .medium))
                                    
                                    if !conv.isSMSChannel {
                                        HStack(spacing: 3 * s) {
                                            Image(systemName: "lock.fill")
                                                .font(.system(size: 10 * s))
                                            Text("已加密")
                                                .font(.system(size: 11 * s, weight: .medium))
                                        }
                                    }
                                }
                                .foregroundStyle(.secondary)
                                .padding(.top, 60 * s)
                                .padding(.bottom, 12 * s)
                                .transition(.opacity)
                            }
                            
                            let lastReadFromMeIdx = msgs.lastIndex(where: { $0.isFromMe && $0.isRead })
                            let lastUnreadFromMeIdx: Int? = {
                                guard let uIdx = msgs.lastIndex(where: { $0.isFromMe && !$0.isRead }) else { return nil }
                                if let rIdx = lastReadFromMeIdx {
                                    return uIdx > rIdx ? uIdx : nil
                                }
                                return uIdx
                            }()
                            
                            ForEach(Array(msgs.enumerated()), id: \.element.id) { index, msg in
                                let receiptStatus: BubbleReceiptStatus = {
                                    guard showReceipts else { return .none }
                                    if index == lastReadFromMeIdx {
                                        return .read
                                    } else if index == lastUnreadFromMeIdx {
                                        return .delivered
                                    } else {
                                        return .none
                                    }
                                }()
                                
                                singleMessageRowView(
                                    conv: conv,
                                    msgs: msgs,
                                    index: index,
                                    msg: msg,
                                    receiptStatus: receiptStatus,
                                    s: s
                                )
                            }
                        }
                    }
                    
                    if isPeerTyping && showTypingIndicator {
                        HStack(spacing: 0) {
                            NativeTypingIndicatorBubble(
                                customBubbleColor: peerBubbleCol,
                                customDotColor: peerTextCol,
                                fontScale: fontRatio
                            )
                            Spacer(minLength: 80 * s)
                        }
                        .padding(.horizontal, 17.2 * s)
                        .padding(.top, 1.5 * s)
                        .padding(.bottom, 4 * fontRatio * s)
                        .id("typing_indicator")
                        .transition(.asymmetric(insertion: .scale(scale: 0.5, anchor: .bottomLeading).combined(with: .opacity), removal: .opacity))
                        .onAppear {
                            DispatchQueue.main.async {
                                withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                                    proxy.scrollTo("bottom_anchor", anchor: .bottom)
                                }
                            }
                        }
                    }
                    
                    Color.clear
                        .frame(height: isInputFocused ? (18.0 * s) : 8.0)
                        .id("bottom_anchor")
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .modifier(IOS26NativeBottomSafeAreaBar {
                if isSelectionMode {
                    nativeBottomSelectionBar
                } else {
                    nativeBottomInputBar
                }
            })
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.04) {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
            }
            .onChange(of: isInputFocused) { _, focused in
                if !focused {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                            proxy.scrollTo("bottom_anchor", anchor: .bottom)
                        }
                    }
                }
            }
            .onChange(of: isPeerTyping) { _, isTyping in
                if isTyping && showTypingIndicator {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                            proxy.scrollTo("bottom_anchor", anchor: .bottom)
                        }
                    }
                }
            }
            .onChange(of: conversation?.messages.count) { oldCount, newCount in
                viewModel.markConversationAsRead(conversationID)
                guard let old = oldCount, let new = newCount, new > old else { return }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.04) {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
            }
            .onAppear {
                ChatNotificationManager.shared.activeViewingConversationID = conversationID
                viewModel.markConversationAsRead(conversationID)
                ChatNotificationManager.shared.requestAuthorization()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                    proxy.scrollTo("bottom_anchor", anchor: .bottom)
                }
            }
            .onDisappear {
                if ChatNotificationManager.shared.activeViewingConversationID == conversationID {
                    ChatNotificationManager.shared.activeViewingConversationID = nil
                }
            }
        }
    }
    
    @ViewBuilder
    private func singleMessageRowView(
        conv: IMConversation,
        msgs: [IMMessageItem],
        index: Int,
        msg: IMMessageItem,
        receiptStatus: BubbleReceiptStatus,
        s: CGFloat
    ) -> some View {
        let showTime = (index == 0) || (msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600)
        let hasTimeGapWithNext = (index + 1 < msgs.count) && (msgs[index + 1].timestamp.timeIntervalSince(msg.timestamp) > 3600)
        let hasTimeGapWithPrev = (index > 0) && (msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600)
        
        let isLastMsg = (index == msgs.count - 1)
        let followedByTyping = isLastMsg && !msg.isFromMe && isPeerTyping && showTypingIndicator
        
        let nextIsSameMsg = (index + 1 < msgs.count) && (msgs[index + 1].isFromMe == msg.isFromMe) && !hasTimeGapWithNext
        let isNextSame = nextIsSameMsg || followedByTyping
        let isPrevSame = (index > 0) && (msgs[index - 1].isFromMe == msg.isFromMe) && !hasTimeGapWithPrev
        
        let myBubbleCol: Color? = customBubbleColorHex.isEmpty ? nil : Color(hex: customBubbleColorHex)
        let myTextCol: Color? = customTextColorHex.isEmpty ? nil : Color(hex: customTextColorHex)
        let peerBubbleCol: Color? = customPeerBubbleColorHex.isEmpty ? nil : Color(hex: customPeerBubbleColorHex)
        let peerTextCol: Color? = customPeerTextColorHex.isEmpty ? nil : Color(hex: customPeerTextColorHex)
        
        NativeMessageBubbleRow(
            message: msg,
            index: index,
            totalCount: msgs.count,
            isPrevSameSender: isPrevSame,
            isNextSameSender: isNextSame,
            receiptStatus: receiptStatus,
            showTimeHeader: showTime,
            isInvisibleRevealed: revealedInvisibleIDs.contains(msg.id),
            fontSize: CGFloat(chatFontSize) * s,
            isSelectionMode: isSelectionMode,
            isSelected: selectedMessageIDs.contains(msg.id),
            enableIOS27Gradient: enableIOS27BubbleGradient,
            customBubbleColor: myBubbleCol,
            customTextColor: myTextCol,
            customPeerBubbleColor: peerBubbleCol,
            customPeerTextColor: peerTextCol,
            onRevealInvisible: {
                withAnimation { _ = revealedInvisibleIDs.insert(msg.id) }
            },
            onToggleSelect: {
                withAnimation(.easeInOut(duration: 0.18)) {
                    if selectedMessageIDs.contains(msg.id) {
                        selectedMessageIDs.remove(msg.id)
                    } else {
                        selectedMessageIDs.insert(msg.id)
                    }
                }
            },
            onStartSelectMode: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    isSelectionMode = true
                    selectedMessageIDs.insert(msg.id)
                }
            },
            onTapback: { symbol in
                viewModel.sendTapback(in: conv.id, messageID: msg.id, symbol: symbol)
            },
            onReply: {
                withAnimation {
                    replyingToMessage = msg
                    isInputFocused = true
                }
            },
            onDelete: {
                withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                    viewModel.deleteSingleMessage(in: conv.id, messageID: msg.id)
                }
                AppHaptic.impact(.light)
            }
        )
        .id(msg.id)
    }
    
    @ViewBuilder
    private var principalHeaderItem: some View {
        let s = uiScale
        if let conv = conversation {
            Button {
                showContactInfoSheet = true
            } label: {
                let arrowSize: CGFloat = 13.3 * s
                let namePill = HStack(spacing: 5.5 * s) {
                    Text(conv.name)
                        .font(.system(size: 17 * s, weight: .bold))
                        .fontWeight(.bold)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    
                    Canvas { context, size in
                        let k = size.height / 11.0
                        var path = Path()
                        path.move(to: CGPoint(x: 1.2 * k, y: 1.5 * k))
                        path.addLine(to: CGPoint(x: 3.0 * k, y: 5.5 * k))
                        path.addLine(to: CGPoint(x: 1.2 * k, y: 9.5 * k))
                        context.stroke(
                            path,
                            with: .color(.secondary.opacity(0.62)),
                            style: StrokeStyle(lineWidth: 2.1 * k, lineCap: .round, lineJoin: .round)
                        )
                    }
                    .frame(width: arrowSize * (4.5 / 11.0), height: arrowSize)
                }
                    .frame(height: 18 * s)
                    .padding(.leading, 12.3 * s)
                    .padding(.trailing, 9.7 * s)
                    .padding(.vertical, 7.5 * s)
                    .frame(maxWidth: 180 * s)
                
                let avatar = NativeContactAvatarView(
                    name: conv.name,
                    colorHex: conv.avatarColorHex,
                    imageID: conv.avatarImageID,
                    size: 58 * s
                )
                    .shadow(color: .black.opacity(0.18), radius: 6 * s, x: 0, y: 3 * s)
                
                ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
                    if #available(iOS 26.0, *) {
                        namePill
                            .glassEffect(.regular.interactive(), in: .capsule)
                            .padding(.top, 53 * s)
                    } else {
                        namePill
                            .background(.regularMaterial, in: Capsule())
                            .padding(.top, 53 * s)
                    }
                    avatar
                }
                .frame(maxWidth: 200 * s)
                .offset(y: 20.7 * s)
            }
            .buttonStyle(.plain)
        }
    }
    
    @ViewBuilder
    private var nativeBottomSelectionBar: some View {
        let s = uiScale
        HStack {
            Button(role: .destructive) {
                showClearAllConfirm = true
            } label: {
                Text("全部删除").font(.system(size: 16 * s)).foregroundStyle(.red)
            }
            Spacer()
            Text(selectedMessageIDs.isEmpty ? "轻点勾选信息" : "已选择 \(selectedMessageIDs.count) 条")
                .font(.system(size: 14 * s)).foregroundStyle(.secondary)
            Spacer()
            Button {
                guard !selectedMessageIDs.isEmpty else { return }
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    viewModel.deleteBatchMessages(in: conversationID, messageIDs: selectedMessageIDs)
                    selectedMessageIDs.removeAll()
                    isSelectionMode = false
                }
                AppHaptic.impact(.light)
            } label: {
                Image(systemName: "trash")
                    .font(.system(size: 19 * s))
                    .foregroundStyle(selectedMessageIDs.isEmpty ? Color.secondary.opacity(0.4) : Color.red)
            }
            .disabled(selectedMessageIDs.isEmpty)
        }
        .padding(.horizontal, 24 * s).padding(.vertical, 12 * s)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .padding(.horizontal, 16 * s).padding(.vertical, 6 * s)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }
    
    @ViewBuilder
    private var nativeBottomInputBar: some View {
        let s = uiScale
        let isTypingActive = isInputFocused || !inputText.isEmpty
        let dynamicInputFontSize: CGFloat = CGFloat(chatFontSize) * s
        let dynamicPlaceholderSize: CGFloat = max(12.0, CGFloat(chatFontSize - 2.0)) * s
        
        let plusMenu = Menu {
            PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                Label("照片", systemImage: "photo.on.rectangle")
            }
            Button {
                showSendEffectSheet = true
            } label: {
                Label("发送特效", systemImage: "sparkles")
            }
            Button {
                showContactInfoSheet = true
            } label: {
                Label("更换对方头像与备注", systemImage: "person.crop.circle")
            }
        } label: {
            Image(systemName: "plus")
                .font(.system(size: 19 * s, weight: .semibold))
                .foregroundStyle(Color(UIColor.label))
                .frame(width: 38 * s, height: 38 * s)
        }
        
        let activeBubbleThemeColor: Color = !customBubbleColorHex.isEmpty ? Color(hex: customBubbleColorHex) : (conversation?.isSMSChannel == true ? Color(hex: "#34C759") : Color(hex: "#007AFF"))
        let sendBtnColor: Color = !customSendButtonColorHex.isEmpty ? Color(hex: customSendButtonColorHex) : activeBubbleThemeColor
        
        let textFieldCapsule = HStack(alignment: .bottom, spacing: 8 * s) {
            ZStack(alignment: .leading) {
                if inputText.isEmpty {
                    Text(conversation?.isSMSChannel == true ? "信息 · 短信" : "iMessage信息")
                        .font(.system(size: dynamicPlaceholderSize))
                        .foregroundStyle(.secondary.opacity(0.44))
                        .padding(.vertical, 8 * s).padding(.leading, 14 * s)
                        .allowsHitTesting(false)
                }
                TextField("", text: $inputText, axis: .vertical)
                    .font(.system(size: dynamicInputFontSize))
                    .lineLimit(1...5)
                    .focused($isInputFocused)
                    .tint(activeBubbleThemeColor)
                    .padding(.vertical, 8 * s).padding(.leading, 14 * s)
            }
            
            if !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Button {
                    commitSend(effect: nil)
                } label: {
                    ZStack {
                        Capsule().fill(sendBtnColor).frame(width: 36 * s, height: 27 * s)
                        Text("↑").font(.system(size: 19 * s, weight: .heavy)).foregroundStyle(.white)
                    }
                }
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                        AppHaptic.impact(.heavy)
                        showSendEffectSheet = true
                    }
                )
                .padding(.trailing, 7 * s).padding(.bottom, 4.2 * s)
            } else {
                Image(systemName: "mic").font(.system(size: 16 * s)).foregroundStyle(Color(hex: "#B2B6BD"))
                    .padding(.trailing, 12.5 * s).padding(.bottom, 7.7 * s)
            }
        }
            .frame(minHeight: 40 * s)
        
        Group {
            if #available(iOS 26.0, *) {
                GlassEffectContainer(spacing: 10 * s) {
                    HStack(alignment: .bottom, spacing: 10 * s) {
                        plusMenu.glassEffect(.regular.interactive(), in: .circle)
                        textFieldCapsule.glassEffect(.regular.interactive(), in: .rect(cornerRadius: 20 * s))
                    }
                }
            } else {
                HStack(alignment: .bottom, spacing: 10 * s) {
                    plusMenu.background(.ultraThinMaterial, in: Circle())
                    textFieldCapsule.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20 * s, style: .continuous))
                }
            }
        }
        .padding(.horizontal, (isTypingActive ? 20 : 25) * s)
        .padding(.bottom, (isInputFocused ? 12 : 0) * s)
        .offset(y: (isInputFocused ? 0 : 10) * s)
        .animation(.spring(response: 0.35, dampingFraction: 0.82), value: isInputFocused)
        .animation(.spring(response: 0.35, dampingFraction: 0.82), value: isTypingActive)
    }
    
    private func clearAllMessages() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
            viewModel.clearConversationMessages(conversationID)
            selectedMessageIDs.removeAll()
            isSelectionMode = false
        }
        AppHaptic.impact(.medium)
    }
    
    private func commitSend(effect: String?) {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        if !customSendAudioFile.isEmpty {
            CustomSoundPlayer.shared.playAudioFile(fileName: customSendAudioFile)
        } else if selectedSendSoundID != 0 {
            let sound = selectedSendSoundID
            DispatchQueue.global(qos: .userInteractive).async {
                AudioServicesPlaySystemSound(SystemSoundID(sound))
            }
        }
        AppHaptic.impact(.light)
        
        withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
            viewModel.sendMessage(in: conversationID, text: trimmed, imageData: nil, replyTo: replyingToMessage, effect: effect)
        }
        inputText = ""
        replyingToMessage = nil
    }
}

// MARK: - 消息气泡单行视图
struct NativeMessageBubbleRow: View {
    let message: IMMessageItem
    var index: Int = 0
    var totalCount: Int = 1
    let isPrevSameSender: Bool
    let isNextSameSender: Bool
    let receiptStatus: BubbleReceiptStatus
    let showTimeHeader: Bool
    let isInvisibleRevealed: Bool
    var fontSize: CGFloat = 16.5
    var isSelectionMode: Bool = false
    var isSelected: Bool = false
    var enableIOS27Gradient: Bool = true
    var customBubbleColor: Color? = nil
    var customTextColor: Color? = nil
    var customPeerBubbleColor: Color? = nil
    var customPeerTextColor: Color? = nil
    let onRevealInvisible: () -> Void
    let onToggleSelect: () -> Void
    let onStartSelectMode: () -> Void
    let onTapback: (String?) -> Void
    let onReply: () -> Void
    let onDelete: () -> Void
    
    @Environment(\.colorScheme) private var colorScheme
    @State private var viewportProgress: CGFloat? = nil
    
    private var fScale: CGFloat { max(0.75, fontSize / max(16.5 * uiScale, 1)) }
    private let tapbackItems: [(symbol: String, label: String)] = [
        ("heart.fill", "爱心"), ("hand.thumbsup.fill", "赞"), ("hand.thumbsdown.fill", "踩"),
        ("face.smiling.inverse", "哈哈"), ("exclamationmark.2", "强调"), ("questionmark", "疑问")
    ]
    
    private var timeString: String {
        let f = DateFormatter()
        f.dateFormat = Calendar.current.isDateInToday(message.timestamp) ? "HH:mm" : "M/d"
        return f.string(from: message.timestamp)
    }
    
    private var headerTimeString: String {
        let f = DateFormatter()
        f.dateFormat = Calendar.current.isDateInToday(message.timestamp) ? "今天 HH:mm" : "M月d日 HH:mm"
        return f.string(from: message.timestamp)
    }
    
    private var rowBottomPadding: CGFloat {
        let s = uiScale
        let hasReceipt = (message.isFromMe && receiptStatus != .none && !isSelectionMode)
        return (isNextSameSender && !hasReceipt) ? ((ChatLayoutConfig.sameSenderBubbleGap * 0.5) * s) : ((ChatLayoutConfig.differentSenderBubbleGap - 2.0) * fScale * s)
    }
    
    var body: some View {
        let s = uiScale
        let k = s * fScale
        let hasReceipt = (message.isFromMe && receiptStatus != .none && !isSelectionMode)
        let hasTail = !isNextSameSender || hasReceipt
        
        VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 3 * s) {
            if showTimeHeader {
                Text(headerTimeString)
                    .font(.system(size: 11 * s, weight: .medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 14 * s).padding(.bottom, 6 * s)
            }
            
            if let preview = message.replyPreview {
                Text("回复：\(preview)")
                    .font(.system(size: 11 * s)).foregroundStyle(.secondary).lineLimit(1).padding(.horizontal, 20 * s)
            }
            
            HStack(alignment: .bottom, spacing: 0) {
                if isSelectionMode {
                    Button(action: onToggleSelect) {
                        Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 22 * s))
                            .foregroundStyle(isSelected ? Color(hex: "#007AFF") : Color.secondary.opacity(0.45))
                            .padding(.trailing, 10 * s)
                    }
                    .buttonStyle(.plain)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                }
                
                if message.isFromMe { Spacer(minLength: 80 * s) }
                
                VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 0) {
                    ZStack(alignment: message.isFromMe ? .topLeading : .topTrailing) {
                        bubbleContentBody(hasTail: hasTail)
                            .frame(maxWidth: 520 * s, alignment: message.isFromMe ? .trailing : .leading)
                            .contextMenu {
                                if !isSelectionMode {
                                    Section {
                                        ForEach(tapbackItems, id: \.symbol) { item in
                                            Button {
                                                onTapback((message.tapback == item.symbol) ? nil : item.symbol)
                                            } label: { Label(item.label, systemImage: item.symbol) }
                                        }
                                    }
                                    Section {
                                        Button(action: onReply) { Label("回复", systemImage: "arrowshape.turn.up.left") }
                                        if !message.text.isEmpty {
                                            Button { UIPasteboard.general.string = message.text } label: { Label("拷贝", systemImage: "doc.on.doc") }
                                        }
                                        Button(action: onStartSelectMode) { Label("更多...", systemImage: "ellipsis.circle") }
                                        Button(role: .destructive, action: onDelete) { Label("删除", systemImage: "trash") }
                                    }
                                }
                            }
                        
                        if let tapSymbol = message.tapback, !isSelectionMode {
                            Image(systemName: tapSymbol)
                                .font(.system(size: 11 * s, weight: .bold))
                                .foregroundStyle(tapSymbol == "heart.fill" ? .pink : .white)
                                .frame(width: 22 * s, height: 22 * s)
                                .background(Color(hex: "#2196F3"), in: Circle())
                                .offset(x: message.isFromMe ? -8 * s : 8 * s, y: -8 * s)
                                .onTapGesture { onTapback(nil) }
                        }
                    }
                    .zIndex(2)
                    
                    if hasReceipt {
                        let baseIndent: CGFloat = hasTail ? ChatLayoutConfig.receiptTrailingWithTail : ChatLayoutConfig.receiptTrailingNoTail
                        NativeReceiptFooterView(
                            receiptStatus: receiptStatus,
                            timeString: timeString,
                            topGap: ChatLayoutConfig.receiptTopGap * k,
                            rightIndent: baseIndent * fScale * s,
                            fontScale: fScale
                        )
                        .zIndex(1).transition(.opacity)
                    }
                }
                
                if !message.isFromMe { Spacer(minLength: 80 * s) }
            }
            .padding(.horizontal, 17.2 * s)
            .contentShape(Rectangle())
            .onTapGesture {
                if isSelectionMode { onToggleSelect() }
            }
        }
        .padding(.top, (isPrevSameSender ? (ChatLayoutConfig.sameSenderBubbleGap * 0.5) : 2.0) * s)
        .padding(.bottom, rowBottomPadding)
        .background(
            GeometryReader { geo in
                Color.clear
                    .onAppear { updateViewportPosition(midY: geo.frame(in: .global).midY) }
                    .onChange(of: geo.frame(in: .global).midY) { _, newMidY in updateViewportPosition(midY: newMidY) }
            }
        )
    }
    
    private func updateViewportPosition(midY: CGFloat) {
        guard message.isFromMe && enableIOS27Gradient else { return }
        let screenH = max(UIScreen.main.bounds.height, 1)
        let normalized = (midY - (screenH * 0.14)) / max(screenH * 0.66, 1)
        let clamped = max(0.0, min(1.0, normalized))
        if viewportProgress == nil || abs((viewportProgress ?? 0) - clamped) > 0.015 {
            viewportProgress = clamped
        }
    }
    
    @ViewBuilder
    private func bubbleContentBody(hasTail: Bool) -> some View {
        let s = uiScale
        let k = s * fScale
        let isInvisible = (message.sendEffect == "invisible") && !isInvisibleRevealed
        let receiveGray = colorScheme == .dark ? Color(UIColor.secondarySystemGroupedBackground) : Color(hex: "#E5E5EA")
        let defaultBubbleColor: Color = message.isFromMe ? (message.isSMS ? Color(hex: "#34C759") : Color(hex: "#007AFF")) : receiveGray
        
        let bubbleColor: Color = {
            if message.isFromMe {
                return enableIOS27Gradient ? Color.ios27PerBubbleColor(progress: viewportProgress ?? 1.0, baseCustomColor: customBubbleColor, isSMS: message.isSMS) : (customBubbleColor ?? defaultBubbleColor)
            } else {
                return customPeerBubbleColor ?? receiveGray
            }
        }()
        
        let textColor: Color = message.isFromMe ? (customTextColor ?? .white) : (customPeerTextColor ?? .primary)
        
        VStack(alignment: .leading, spacing: 4 * s) {
            if let imgID = message.imageID, let data = LocalImageStore.shared.load(id: imgID), let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg).resizable().scaledToFill()
                    .frame(maxWidth: 280 * s, maxHeight: 300 * s)
                    .clipShape(RoundedRectangle(cornerRadius: 20 * s, style: .continuous))
            }
            if !message.text.isEmpty {
                Text(message.text)
                    .font(.system(size: fontSize))
                    .foregroundStyle(textColor)
                    .padding(.vertical, 9 * k).padding(.horizontal, 12 * k)
                    .frame(minWidth: 48 * k)
                    .background(CompositeBubbleBackground(isFromMe: message.isFromMe, hasTail: hasTail, tintColor: bubbleColor, fontScale: fScale))
            }
        }
        .blur(radius: isInvisible ? 6 * s : 0)
        .onTapGesture {
            if isInvisible { onRevealInvisible() }
        }
    }
}

// MARK: - 对方正在输入三点气泡
struct NativeTypingIndicatorBubble: View {
    var customBubbleColor: Color? = nil
    var customDotColor: Color? = nil
    var fontScale: CGFloat = 1.0
    @Environment(\.colorScheme) private var colorScheme
    @State private var animate = false
    
    var body: some View {
        let k = uiScale * fontScale
        let defaultFill = colorScheme == .dark ? Color(UIColor.secondarySystemGroupedBackground) : Color(hex: "#E5E5EA")
        let defaultDot = colorScheme == .dark ? Color(white: 0.65) : Color(hex: "#8E8E93")
        let bubbleFill = customBubbleColor ?? defaultFill
        let dotColor = customDotColor ?? defaultDot
        
        ZStack(alignment: .bottomLeading) {
            Circle().fill(bubbleFill).frame(width: 6 * k, height: 6 * k).offset(x: -5.5 * k, y: 5.5 * k)
            Circle().fill(bubbleFill).frame(width: 12 * k, height: 12 * k).offset(x: -1 * k, y: 1 * k)
            Capsule().fill(bubbleFill).frame(width: 58 * k, height: 36 * k)
            HStack(spacing: 4 * k) {
                ForEach(0..<3, id: \.self) { idx in
                    Circle().fill(dotColor).frame(width: 8.5 * k, height: 8.5 * k).opacity(animate ? 0.95 : 0.32)
                        .animation(.easeInOut(duration: 0.55).repeatForever(autoreverses: true).delay(Double(idx) * 0.17), value: animate)
                }
            }
            .frame(width: 58 * k, height: 36 * k)
        }
        .onAppear { animate = true }
    }
}

// MARK: - 联系人详情原生 Form Sheet
@MainActor
struct NativeContactDetailSheet: View {
    let conversation: IMConversation
    @Binding var avatarPhotoItem: PhotosPickerItem?
    @Binding var selectedSendSoundID: Int
    @Binding var selectedReceiveSoundID: Int
    @Binding var customBubbleColorHex: String
    @Binding var customTextColorHex: String
    @Binding var customPeerBubbleColorHex: String
    @Binding var customPeerTextColorHex: String
    @Binding var customSendButtonColorHex: String
    @Binding var bgImageID: String
    @Binding var chatFontSize: Double
    @Binding var enableIOS27BubbleGradient: Bool
    @Binding var showReceipts: Bool
    @Binding var showTypingIndicator: Bool
    
    @Binding var customSendAudioFile: String
    @Binding var customSendAudioName: String
    @Binding var customReceiveAudioFile: String
    @Binding var customReceiveAudioName: String
    
    let onClearAll: () -> Void
    @ObservedObject var viewModel = MessagesViewModel.shared
    @Environment(\.dismiss) private var dismiss
    @State private var editingName: String = ""
    @State private var bgPhotoItem: PhotosPickerItem? = nil
    
    @State private var myBubbleColor: Color = Color(hex: "#007AFF")
    @State private var myTextColor: Color = .white
    @State private var peerBubbleColor: Color = Color(hex: "#E5E5EA")
    @State private var peerTextColor: Color = .primary
    @State private var sendButtonColor: Color = Color(hex: "#007AFF")
    @State private var showConfirmClearInSheet: Bool = false
    @State private var showSendAudioFilePicker: Bool = false
    @State private var showReceiveAudioFilePicker: Bool = false
    
    private let bubblePresets: [(name: String, hex: String)] = [
        ("经典蓝", "#007AFF"), ("信息绿", "#34C759"), ("霓虹紫", "#AF52DE"),
        ("活力橙", "#FF9500"), ("曜石黑", "#1C1C1E"), ("樱花粉", "#FF2D55"), ("原生灰", "#E5E5EA")
    ]
    
    private var supportedAudioTypes: [UTType] {
        var types: [UTType] = [.audio, .mp3, .wav]
        if let m4a = UTType(filenameExtension: "m4a") { types.append(m4a) }
        if let aac = UTType(filenameExtension: "aac") { types.append(aac) }
        if let caf = UTType(filenameExtension: "caf") { types.append(caf) }
        return types
    }
    
    var body: some View {
        let s = uiScale
        let convName = conversation.name
        let convColorHex = conversation.avatarColorHex
        let convAvatarID = conversation.avatarImageID
        let currentBgID = bgImageID
        
        NavigationStack {
            Form {
                Section {
                    VStack(spacing: 8 * s) {
                        PhotosPicker(selection: $avatarPhotoItem, matching: .images, photoLibrary: .shared()) {
                            NativeContactAvatarView(name: convName, colorHex: convColorHex, imageID: convAvatarID, size: 72 * s)
                        }
                        .buttonStyle(.plain)
                        Text("轻点更换头像").font(.caption).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity).listRowBackground(Color.clear)
                }
                
                Section {
                    Toggle("显示已读 / 已送达回执与时间", isOn: $showReceipts)
                    Toggle("显示「对方正在输入…」气泡", isOn: $showTypingIndicator)
                } header: { Text("状态与回执显示") }
                
                Section("气泡与输入框文字大小调节") {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("A").font(.system(size: 13, weight: .medium))
                            Slider(value: $chatFontSize, in: 13...24, step: 0.5)
                            Text("A").font(.system(size: 22, weight: .bold))
                        }
                        HStack {
                            Text("当前字号: \(String(format: "%.1f", chatFontSize)) pt").font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            if chatFontSize != 16.5 { Button("恢复默认") { chatFontSize = 16.5 }.font(.caption) }
                        }
                    }.padding(.vertical, 4)
                }
                
                Section("聊天背景壁纸") {
                    PhotosPicker(selection: $bgPhotoItem, matching: .images, photoLibrary: .shared()) {
                        HStack {
                            Label("从相册选择壁纸", systemImage: "photo.fill")
                            Spacer()
                            if !currentBgID.isEmpty, let data = LocalImageStore.shared.load(id: currentBgID), let uiImg = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImg).resizable().scaledToFill().frame(width: 32, height: 32).clipShape(RoundedRectangle(cornerRadius: 6))
                            }
                        }
                    }
                    if !currentBgID.isEmpty {
                        Button(role: .destructive) { bgImageID = "" } label: { Label("恢复默认背景", systemImage: "trash") }
                    }
                }
                
                Section {
                    Toggle("iOS 27 逐条位置渐变", isOn: $enableIOS27BubbleGradient)
                    ColorPicker("底部最后一条基础色", selection: $myBubbleColor, supportsOpacity: false)
                        .onChange(of: myBubbleColor) { _, newColor in customBubbleColorHex = newColor.toHexString() }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(bubblePresets, id: \.hex) { preset in
                                Button {
                                    myBubbleColor = Color(hex: preset.hex)
                                    customBubbleColorHex = preset.hex
                                } label: {
                                    Circle().fill(Color(hex: preset.hex)).frame(width: 28, height: 28)
                                        .overlay { if customBubbleColorHex == preset.hex { Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.white) } }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    
                    ColorPicker("文字颜色", selection: $myTextColor, supportsOpacity: false)
                        .onChange(of: myTextColor) { _, newColor in customTextColorHex = newColor.toHexString() }
                    
                    ColorPicker("发送箭头按钮颜色", selection: $sendButtonColor, supportsOpacity: false)
                        .onChange(of: sendButtonColor) { _, newColor in customSendButtonColorHex = newColor.toHexString() }
                } header: { Text("我方气泡与文字颜色") }
                
                Section("对方气泡与文字颜色") {
                    ColorPicker("对方气泡颜色", selection: $peerBubbleColor, supportsOpacity: false)
                        .onChange(of: peerBubbleColor) { _, newColor in customPeerBubbleColorHex = newColor.toHexString() }
                    
                    ColorPicker("对方文字与输入圆点颜色", selection: $peerTextColor, supportsOpacity: false)
                        .onChange(of: peerTextColor) { _, newColor in customPeerTextColorHex = newColor.toHexString() }
                }
                
                Section {
                    // 我发信音
                    VStack(alignment: .leading, spacing: 8) {
                        Text("我发消息时的提示音").font(.system(size: 15, weight: .medium))
                        if !customSendAudioFile.isEmpty {
                            HStack {
                                Label("自定义: \(customSendAudioName)", systemImage: "music.note").font(.system(size: 14)).foregroundStyle(.blue)
                                Spacer()
                                Button { CustomSoundPlayer.shared.playAudioFile(fileName: customSendAudioFile) } label: { Image(systemName: "play.circle.fill").font(.system(size: 20)).foregroundStyle(.blue) }.buttonStyle(.plain)
                                Button { CustomSoundPlayer.shared.deleteAudioFile(fileName: customSendAudioFile); customSendAudioFile = ""; customSendAudioName = "" } label: { Image(systemName: "trash").font(.system(size: 15)).foregroundStyle(.red) }.buttonStyle(.plain)
                            }
                        } else {
                            Picker("选择系统铃声", selection: $selectedSendSoundID) {
                                ForEach(chatSendSoundOptions) { Text($0.name).tag($0.id) }
                            }
                            .onChange(of: selectedSendSoundID) { _, sound in
                                if sound != 0 { DispatchQueue.global(qos: .userInteractive).async { AudioServicesPlaySystemSound(SystemSoundID(sound)) } }
                            }
                        }
                        Button { showSendAudioFilePicker = true } label: {
                            HStack(spacing: 6) { Image(systemName: "square.and.arrow.down"); Text(customSendAudioFile.isEmpty ? "从「文件」上传本地音频 (.mp3/.m4a/.wav)" : "更换本地音频") }.font(.system(size: 13, weight: .medium))
                        }
                    }.padding(.vertical, 4)
                    
                    // 对方回复音
                    VStack(alignment: .leading, spacing: 8) {
                        Text("对方回复时的提示音").font(.system(size: 15, weight: .medium))
                        if !customReceiveAudioFile.isEmpty {
                            HStack {
                                Label("自定义: \(customReceiveAudioName)", systemImage: "music.note").font(.system(size: 14)).foregroundStyle(.green)
                                Spacer()
                                Button { CustomSoundPlayer.shared.playAudioFile(fileName: customReceiveAudioFile) } label: { Image(systemName: "play.circle.fill").font(.system(size: 20)).foregroundStyle(.green) }.buttonStyle(.plain)
                                Button { CustomSoundPlayer.shared.deleteAudioFile(fileName: customReceiveAudioFile); customReceiveAudioFile = ""; customReceiveAudioName = "" } label: { Image(systemName: "trash").font(.system(size: 15)).foregroundStyle(.red) }.buttonStyle(.plain)
                            }
                        } else {
                            Picker("选择系统铃声", selection: $selectedReceiveSoundID) {
                                ForEach(chatReceiveSoundOptions) { Text($0.name).tag($0.id) }
                            }
                            .onChange(of: selectedReceiveSoundID) { _, sound in
                                if sound != 0 { DispatchQueue.global(qos: .userInteractive).async { AudioServicesPlaySystemSound(SystemSoundID(sound)) } }
                            }
                        }
                        Button { showReceiveAudioFilePicker = true } label: {
                            HStack(spacing: 6) { Image(systemName: "square.and.arrow.down"); Text(customReceiveAudioFile.isEmpty ? "从「文件」上传本地音频 (.mp3/.m4a/.wav)" : "更换本地音频") }.font(.system(size: 13, weight: .medium))
                        }
                    }.padding(.vertical, 4)
                } header: { Text("提示铃声音效") }
                
                Section("联系人资料") {
                    LabeledContent("备注昵称") { TextField("昵称", text: $editingName).multilineTextAlignment(.trailing) }
                    LabeledContent("iMessage 号码", value: conversation.peerID)
                    Button("拷贝号码") { UIPasteboard.general.string = conversation.peerID }
                }
                
                Section {
                    Button(role: .destructive) { showConfirmClearInSheet = true } label: {
                        HStack { Spacer(); Text("清空该对话所有聊天记录"); Spacer() }
                    }
                }
            }
            .navigationTitle("详情")
            .navigationBarTitleDisplayMode(.inline)
            .confirmationDialog("确定要清空该会话所有聊天记录吗？此操作无法撤销。", isPresented: $showConfirmClearInSheet, titleVisibility: .visible) {
                Button("清空所有信息", role: .destructive) { onClearAll(); dismiss() }
                Button("取消", role: .cancel) {}
            }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        let trimmed = editingName.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty, let idx = viewModel.conversations.firstIndex(where: { $0.id == conversation.id }) else { dismiss(); return }
                        viewModel.conversations[idx].name = trimmed
                        viewModel.saveConversations()
                        dismiss()
                    }
                }
            }
            .onAppear {
                editingName = conversation.name
                if !customBubbleColorHex.isEmpty { myBubbleColor = Color(hex: customBubbleColorHex) }
                if !customTextColorHex.isEmpty { myTextColor = Color(hex: customTextColorHex) }
                if !customPeerBubbleColorHex.isEmpty { peerBubbleColor = Color(hex: customPeerBubbleColorHex) }
                if !customPeerTextColorHex.isEmpty { peerTextColor = Color(hex: customPeerTextColorHex) }
                if !customSendButtonColorHex.isEmpty { sendButtonColor = Color(hex: customSendButtonColorHex) }
            }
            .task(id: bgPhotoItem) {
                if let item = bgPhotoItem, let data = try? await item.loadTransferable(type: Data.self) {
                    if let savedID = LocalImageStore.shared.save(data: data) { bgImageID = savedID }
                    bgPhotoItem = nil
                }
            }
            .fileImporter(isPresented: $showSendAudioFilePicker, allowedContentTypes: supportedAudioTypes, allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first, let savedFile = CustomSoundPlayer.shared.saveAudioFile(from: url) {
                    customSendAudioFile = savedFile
                    customSendAudioName = url.deletingPathExtension().lastPathComponent
                    CustomSoundPlayer.shared.playAudioFile(fileName: savedFile)
                    AppHaptic.notify(.success)
                }
            }
            .fileImporter(isPresented: $showReceiveAudioFilePicker, allowedContentTypes: supportedAudioTypes, allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first, let savedFile = CustomSoundPlayer.shared.saveAudioFile(from: url) {
                    customReceiveAudioFile = savedFile
                    customReceiveAudioName = url.deletingPathExtension().lastPathComponent
                    CustomSoundPlayer.shared.playAudioFile(fileName: savedFile)
                    AppHaptic.notify(.success)
                }
            }
        }
    }
}
