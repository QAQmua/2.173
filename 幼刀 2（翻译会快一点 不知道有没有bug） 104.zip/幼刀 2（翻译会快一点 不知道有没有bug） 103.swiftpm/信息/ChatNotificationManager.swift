// 📄 完整替换文件：信息/ChatNotificationManager.swift
import SwiftUI
import UserNotifications
import Intents
import AVFoundation
import UIKit

@MainActor
class ChatNotificationManager: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ChatNotificationManager()
    
    private var bgTask: UIBackgroundTaskIdentifier = .invalid
    private var silentPlayer: AVAudioPlayer?
    private var keepAliveTimer: Timer?
    
    public var activeViewingConversationID: String? = nil
    
    private override init() {
        super.init()
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        setupNotificationCategories(center)
        setupBackgroundLifecycleHooks()
        prepareSilentAudioKeepAlive()
    }
    
    private func setupNotificationCategories(_ center: UNUserNotificationCenter) {
        let msgCategory = UNNotificationCategory(
            identifier: "IMESSAGE_COMMUNICATION_CATEGORY",
            actions: [],
            intentIdentifiers: [NSStringFromClass(INSendMessageIntent.self)],
            options: [.allowInCarPlay]
        )
        center.setNotificationCategories([msgCategory])
    }
    
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge, .providesAppNotificationSettings]) { granted, error in
            if let error = error {
                print("❌ 通知授权失败: \(error.localizedDescription)")
            }
        }
    }
    
    /// 🌟 核心：构造 Apple 原生 Communication Notification
    /// 使系统锁屏与顶部横幅直接展示【联系人大圆形头像 + 昵称】，App 图标自动微缩在头像右下角！
    func scheduleMessageNotification(
        messageID: String = UUID().uuidString,
        senderName: String,
        messageText: String,
        conversationID: String,
        avatarImageID: String? = nil,
        avatarColorHex: String = "#007AFF",
        hasImageAttachment: Bool = false
    ) {
        let appState = UIApplication.shared.applicationState
        if appState == .active && activeViewingConversationID == conversationID {
            return
        }
        
        let baseContent = UNMutableNotificationContent()
        baseContent.title = senderName
        baseContent.body = messageText.isEmpty ? (hasImageAttachment ? "[图片]" : "发来一条新信息") : messageText
        baseContent.sound = .default
        baseContent.threadIdentifier = conversationID
        baseContent.categoryIdentifier = "IMESSAGE_COMMUNICATION_CATEGORY"
        
        // 渲染高清大尺寸圆形联系人头像
        let avatarData: Data? = {
            if let id = avatarImageID,
               let raw = LocalImageStore.shared.load(id: id),
               let uiImg = UIImage(data: raw),
               let circularData = Self.renderCircularAvatarPNG(image: uiImg, size: 240) {
                return circularData
            }
            return Self.renderMonogramAvatarPNG(name: senderName, colorHex: avatarColorHex, size: 240)
        }()
        
        // 1. 挂载附件头像作为系统兜底缩略图
        if let data = avatarData {
            let tmpURL = FileManager.default.temporaryDirectory.appendingPathComponent("notif_av_\(messageID).png")
            if (try? data.write(to: tmpURL)) != nil,
               let attachment = try? UNNotificationAttachment(identifier: "avatar_attach_\(messageID)", url: tmpURL, options: nil) {
                baseContent.attachments = [attachment]
            }
        }
        
        // 2. 构造符合 iOS 15+ / iOS 16+ / iOS 17+ / iOS 18+ 原生 Communication Notification 规范的 INSendMessageIntent
        var finalContent: UNNotificationContent = baseContent
        if let data = avatarData {
            let inImage = INImage(imageData: data)
            let handle = INPersonHandle(value: conversationID, type: .unknown)
            
            var nameComponents = PersonNameComponents()
            nameComponents.givenName = senderName
            
            let senderPerson = INPerson(
                personHandle: handle,
                nameComponents: nameComponents,
                displayName: senderName,
                image: inImage,
                contactIdentifier: conversationID,
                customIdentifier: conversationID
            )
            
            let sendIntent = INSendMessageIntent(
                recipients: nil,
                outgoingMessageType: .outgoingMessageText,
                content: baseContent.body,
                speakableGroupName: nil,
                conversationIdentifier: conversationID,
                serviceName: "iMessage",
                sender: senderPerson,
                attachments: nil
            )
            sendIntent.setImage(inImage, forParameterNamed: \.sender)
            
            let interaction = INInteraction(intent: sendIntent, response: nil)
            interaction.direction = .incoming
            interaction.donate(completion: nil)
            
            do {
                finalContent = try baseContent.updating(from: sendIntent)
            } catch {
                finalContent = baseContent
            }
        }
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
        let request = UNNotificationRequest(
            identifier: "im_msg_\(messageID)",
            content: finalContent,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ 锁屏/后台通知派发失败: \(error.localizedDescription)")
            }
        }
    }
    
    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .list, .badge])
    }
    
    private func setupBackgroundLifecycleHooks() {
        NotificationCenter.default.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.beginBackgroundKeepAlive()
            }
        }
        
        NotificationCenter.default.addObserver(
            forName: UIApplication.willEnterForegroundNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.endBackgroundKeepAlive()
                MessagesNetworkEngine.shared.ensureAliveAndSync()
            }
        }
    }
    
    private func beginBackgroundKeepAlive() {
        if bgTask != .invalid {
            UIApplication.shared.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "IMessageSocketKeepAlive") { [weak self] in
            Task { @MainActor in
                if let task = self?.bgTask, task != .invalid {
                    UIApplication.shared.endBackgroundTask(task)
                    self?.bgTask = .invalid
                }
            }
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            silentPlayer?.play()
        } catch {}
        
        keepAliveTimer?.invalidate()
        keepAliveTimer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: true) { _ in
            Task { @MainActor in
                MessagesNetworkEngine.shared.ensureAliveAndSync()
            }
        }
    }
    
    private func endBackgroundKeepAlive() {
        keepAliveTimer?.invalidate()
        keepAliveTimer = nil
        silentPlayer?.pause()
        if bgTask != .invalid {
            UIApplication.shared.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
    }
    
    private func prepareSilentAudioKeepAlive() {
        let sampleRate: Int32 = 8000
        let numSamples: Int32 = 8000
        let dataSize = numSamples * 2
        let fileSize = 36 + dataSize
        
        var wav = Data()
        wav.append("RIFF".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: fileSize.littleEndian) { Data($0) })
        wav.append("WAVEfmt ".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: Int32(16).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(1).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(1).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: sampleRate.littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: (sampleRate * 2).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(2).littleEndian) { Data($0) })
        wav.append(withUnsafeBytes(of: Int16(16).littleEndian) { Data($0) })
        wav.append("data".data(using: .ascii)!)
        wav.append(withUnsafeBytes(of: dataSize.littleEndian) { Data($0) })
        wav.append(Data(count: Int(dataSize)))
        
        if let player = try? AVAudioPlayer(data: wav) {
            player.numberOfLoops = -1
            player.volume = 0.0
            player.prepareToPlay()
            self.silentPlayer = player
        }
    }
    
    private static func renderCircularAvatarPNG(image: UIImage, size: CGFloat) -> Data? {
        let rect = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        let renderer = UIGraphicsImageRenderer(size: rect.size)
        let img = renderer.image { ctx in
            UIBezierPath(ovalIn: rect).addClip()
            let imgSize = image.size
            let scale = max(size / max(imgSize.width, 1), size / max(imgSize.height, 1))
            let drawW = imgSize.width * scale
            let drawH = imgSize.height * scale
            let drawRect = CGRect(x: (size - drawW) / 2.0, y: (size - drawH) / 2.0, width: drawW, height: drawH)
            image.draw(in: drawRect)
        }
        return img.pngData()
    }
    
    private static func renderMonogramAvatarPNG(name: String, colorHex: String, size: CGFloat) -> Data? {
        let rect = CGRect(origin: .zero, size: CGSize(width: size, height: size))
        let renderer = UIGraphicsImageRenderer(size: rect.size)
        let baseColor = UIColor(Color(hex: colorHex))
        let img = renderer.image { ctx in
            let path = UIBezierPath(ovalIn: rect)
            path.addClip()
            baseColor.setFill()
            path.fill()
            
            let firstChar = String(name.isEmpty ? "信" : name.prefix(1))
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            let font = UIFont.systemFont(ofSize: size * 0.46, weight: .bold)
            let attrs: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraph
            ]
            let textSize = firstChar.size(withAttributes: attrs)
            let textRect = CGRect(
                x: 0,
                y: (size - textSize.height) / 2.0,
                width: size,
                height: textSize.height
            )
            firstChar.draw(in: textRect, withAttributes: attrs)
        }
        return img.pngData()
    }
}
