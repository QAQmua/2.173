// 📄 新建文件：信息/MessagesComponents.swift
import SwiftUI
import AudioToolbox

// MARK: - 1. 间距与布局微调配置
enum ChatLayoutConfig {
    static let sameSenderBubbleGap: CGFloat = 3.8
    static let differentSenderBubbleGap: CGFloat = 6.0
    static let receiptTopGap: CGFloat = 6.5
    static let receiptTrailingWithTail: CGFloat = 20
    static let receiptTrailingNoTail: CGFloat = 6.0
    static let receiptTextToTimeSpacing: CGFloat = 3.0
}

// MARK: - 2. 铃声音效选项定义
struct ChatSoundOption: Identifiable, Hashable {
    let id: Int
    let name: String
}

let chatSendSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1004, name: "经典飞跃 (Swoosh - 默认)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1000, name: "清脆铃音 (Ding)"),
    ChatSoundOption(id: 1001, name: "疾风邮件 (Whoosh)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

let chatReceiveSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1005, name: "经典三音 (Tri-tone - 默认)"),
    ChatSoundOption(id: 1003, name: "电子短音 (Note)"),
    ChatSoundOption(id: 1002, name: "玻璃轻敲 (Glass)"),
    ChatSoundOption(id: 1000, name: "清脆叮咚 (Ding)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

// MARK: - 3. 气泡渐变色扩展
extension Color {
    func toHexString() -> String {
        let uic = UIColor(self)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard uic.getRed(&r, green: &g, blue: &b, alpha: &a) else { return "#007AFF" }
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
    
    static func ios27PerBubbleColor(progress: CGFloat, baseCustomColor: Color?, isSMS: Bool) -> Color {
        let t = max(0.0, min(1.0, progress))
        let upward = 1.0 - t
        
        if let custom = baseCustomColor {
            let uic = UIColor(custom)
            var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
            if uic.getHue(&h, saturation: &s, brightness: &b, alpha: &a) {
                let finalH = (h - upward * 0.03 + 1.0).truncatingRemainder(dividingBy: 1.0)
                let finalS = max(0.12, min(1.0, s * (1.0 - upward * 0.32)))
                let finalB = max(0.20, min(1.0, b + (1.0 - b) * (upward * 0.45)))
                return Color(hue: Double(finalH), saturation: Double(finalS), brightness: Double(finalB))
            }
            return custom
        }
        
        if isSMS {
            let r = 0.204 + (0.388 - 0.204) * upward
            let g = 0.780 + (0.902 - 0.780) * upward
            let b = 0.349 + (0.510 - 0.349) * upward
            return Color(.sRGB, red: Double(r), green: Double(g), blue: Double(b), opacity: 1.0)
        }
        
        let r = 0.000 + (0.220 - 0.000) * upward
        let g = 0.478 + (0.675 - 0.478) * upward
        let b = 1.000
        return Color(.sRGB, red: Double(r), green: Double(g), blue: Double(b), opacity: 1.0)
    }
}

// MARK: - 4. 回执枚举与视图
public enum BubbleReceiptStatus: Equatable {
    case none
    case delivered
    case read
}

struct NativeReceiptFooterView: View {
    let receiptStatus: BubbleReceiptStatus
    let timeString: String
    let topGap: CGFloat
    let rightIndent: CGFloat
    var fontScale: CGFloat = 1.0
    
    var body: some View {
        let s = uiScale
        let k = s * fontScale
        let receiptFontSize: CGFloat = 11 * k
        
        ZStack(alignment: .trailing) {
            if receiptStatus == .delivered {
                Text("已送达")
                    .font(.system(size: receiptFontSize, weight: .bold))
                    .bold()
                    .foregroundStyle(.secondary)
            } else if receiptStatus == .read {
                HStack(spacing: ChatLayoutConfig.receiptTextToTimeSpacing * k) {
                    Text(timeString)
                        .font(.system(size: receiptFontSize, weight: .regular))
                    Text("已读")
                        .font(.system(size: receiptFontSize, weight: .bold))
                        .bold()
                }
                .foregroundStyle(.secondary)
            }
        }
        .padding(.top, topGap)
        .padding(.trailing, rightIndent)
    }
}

// MARK: - 5. 气泡尾巴网图单例加载器
class RemoteTailImageLoader: ObservableObject {
    static let shared = RemoteTailImageLoader()
    @Published var tailImage: UIImage? = nil
    
    private init() {
        guard let url = URL(string: "https://i.postimg.cc/k5pv6GGG/wu-biao-ti672-20260207151704.png") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let img = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.tailImage = img
                }
            }
        }.resume()
    }
}

// MARK: - 6. 气泡背景拼接组件
struct CompositeBubbleBackground: View {
    let isFromMe: Bool
    let hasTail: Bool
    let tintColor: Color
    var fontScale: CGFloat = 1.0
    
    @StateObject private var loader = RemoteTailImageLoader.shared
    
    var body: some View {
        let k = uiScale * fontScale
        ZStack(alignment: isFromMe ? .bottomTrailing : .bottomLeading) {
            RoundedRectangle(cornerRadius: 19 * k, style: .continuous)
                .fill(tintColor)
            
            if hasTail {
                if let uiImage = loader.tailImage {
                    Image(uiImage: uiImage)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 20 * k, height: 20 * k)
                        .foregroundStyle(tintColor)
                        .scaleEffect(x: isFromMe ? 1 : -1, y: 1)
                        .offset(x: isFromMe ? -3.4 * k : 3.4 * k, y: 9.15 * k)
                }
            }
        }
        .compositingGroup()
    }
}

// MARK: - 7. 原生输入栏安全区域修饰器
struct IOS26NativeBottomSafeAreaBar<BarContent: View>: ViewModifier {
    @ViewBuilder let barContent: () -> BarContent
    
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content
                .safeAreaBar(edge: .bottom) {
                    barContent()
                }
                .scrollEdgeEffectStyle(.soft, for: .bottom)
        } else {
            content
                .safeAreaInset(edge: .bottom) {
                    barContent()
                }
        }
    }
}
