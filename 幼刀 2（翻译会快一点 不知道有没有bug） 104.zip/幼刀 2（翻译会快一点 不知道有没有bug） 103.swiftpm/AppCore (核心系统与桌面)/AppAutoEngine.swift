// 📄 替换文件：AppCore (核心系统与桌面)/AppAutoEngine.swift
// 核心：纯净自注册引擎，已彻底剔除所有 App 名字的硬编码
import SwiftUI
import ObjectiveC

// MARK: - 1. 插件基础契约
@MainActor
open class BaseAppPlugin: NSObject {
    open class var id: String { "" }
    open class var name: String { "" }
    open class var icon: String { "app.fill" }
    open class var colorName: String { "blue" }
    open class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(EmptyView())
    }
}

@MainActor
open class BaseWidgetPlugin: NSObject {
    open class func register() {}
}

// MARK: - 2. 插件全自动装配中心
@MainActor
public final class AppAutoEngine {
    public static let shared = AppAutoEngine()
    private var isBooted = false
    
    public static func boot() {
        shared.start()
    }
    
    public func start() {
        guard !isBooted else { return }
        isBooted = true
        
        // 1. 运行时全自动检索并注册所有 App（无论是系统内置还是新增的第三方）
        scanAndRegisterAppPlugins()
        
        // 2. 运行时全自动检索并注册所有桌面小组件
        scanAndRegisterWidgetPlugins()
    }
    
    // 扫描所有继承了 BaseAppPlugin 的类
    private func scanAndRegisterAppPlugins() {
        var count: UInt32 = 0
        guard let classList = objc_copyClassList(&count) else { return }
        defer { free(UnsafeMutableRawPointer(classList)) }
        
        let classes = UnsafeBufferPointer(start: classList, count: Int(count))
        var newAppItems: [AppItem] = []
        
        for cls in classes {
            if isSubclass(cls, of: BaseAppPlugin.self), let plugin = cls as? BaseAppPlugin.Type {
                let appId = plugin.id
                // 忽略没有指定 id 的基类
                guard !appId.isEmpty else { continue }
                
                AppRegistry.shared.register(
                    id: appId,
                    name: plugin.name,
                    icon: plugin.icon,
                    colorName: plugin.colorName
                ) { show in
                    plugin.buildView(show: show)
                }
                
                newAppItems.append(AppItem(
                    id: appId,
                    title: plugin.name,
                    icon: plugin.icon,
                    colorName: plugin.colorName
                ))
            }
        }
        
        // 自动同步上屏
        syncNewAppsToDesktop(newAppItems)
    }
    
    // 扫描所有继承了 BaseWidgetPlugin 的类
    private func scanAndRegisterWidgetPlugins() {
        var count: UInt32 = 0
        guard let classList = objc_copyClassList(&count) else { return }
        defer { free(UnsafeMutableRawPointer(classList)) }
        
        let classes = UnsafeBufferPointer(start: classList, count: Int(count))
        for cls in classes {
            if isSubclass(cls, of: BaseWidgetPlugin.self), let plugin = cls as? BaseWidgetPlugin.Type {
                plugin.register()
            }
        }
    }
    
    // 将扫描到的 App 自动补全到桌面上（如果桌面上还没有的话）
    private func syncNewAppsToDesktop(_ newApps: [AppItem]) {
        guard !newApps.isEmpty else { return }
        let gridKey = "App_HomeScreen_Grid24_Data_Clean"
        let dockKey = "App_HomeScreen_Dock4_Data_Clean"
        
        var apps: [AppItem?] = []
        if let data = UserDefaults.standard.data(forKey: gridKey),
           let decoded = try? JSONDecoder().decode([AppItem?].self, from: data) {
            apps = decoded
        }
        var dockApps: [AppItem] = []
        if let data = UserDefaults.standard.data(forKey: dockKey),
           let decoded = try? JSONDecoder().decode([AppItem].self, from: data) {
            dockApps = decoded
        }
        
        let existingIds = Set(apps.compactMap { $0?.id } + dockApps.map { $0.id })
        var hasChanged = false
        
        for app in newApps {
            if !existingIds.contains(app.id) {
                if let freeIndex = apps.firstIndex(where: { $0 == nil }) {
                    apps[freeIndex] = app
                } else {
                    apps.append(app)
                }
                hasChanged = true
            }
        }
        
        if hasChanged {
            if let data = try? JSONEncoder().encode(apps) {
                UserDefaults.standard.set(data, forKey: gridKey)
            }
        }
    }
    
    private func isSubclass(_ cls: AnyClass, of parent: AnyClass) -> Bool {
        var current: AnyClass? = class_getSuperclass(cls)
        while let c = current {
            if c == parent { return true }
            current = class_getSuperclass(c)
        }
        return false
    }
}

// MARK: - 3. 统一全局手势扩展
extension View {
    public func enableSwipeDismiss(show: Binding<Bool>) -> some View {
        self.simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show.wrappedValue = false }
                }
            }
        )
    }
}
