import SwiftUI

// 📄 拖拽实时位置追踪器
@MainActor
final class DragPositionTracker: ObservableObject {
    @Published var offset: CGSize = .zero
    @Published var location: CGPoint = .zero
}

// 📄 App 图标拖拽协同与交互中枢
@MainActor
final class DragCoordinator: ObservableObject {
    @Published var activeDraggingItem: AppItem? = nil
    @Published var activeDragSource: AppLocation? = nil
    let positionTracker = DragPositionTracker()
    
    var currentEdgeDirection: Int? = nil
    var edgePagingTask: Task<Void, Never>? = nil
    var isPagingAnimating: Bool = false
    var lastTouchLocation: CGPoint = .zero
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    private let lightImpact = UIImpactFeedbackGenerator(style: .light)
    
    func start(item: AppItem, source: AppLocation, location: CGPoint) {
        activeDraggingItem = item
        activeDragSource = source
        positionTracker.location = location
    }
    
    func update(location: CGPoint) {
        positionTracker.location = location
    }
    
    func reset() {
        activeDraggingItem = nil
        activeDragSource = nil
        positionTracker.location = .zero
        cancelEdgePaging()
    }
    
    func handleEdgePaging(
        localLocation: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        currentPage: Binding<Int>,
        viewModel: HomeScreenViewModel
    ) {
        guard viewModel.isEditing else { return }
        lastTouchLocation = localLocation
        
        let isDockArea = localLocation.y >= (screenH - dockTriggerH)
        guard !isDockArea else { cancelEdgePaging(); return }
        
        let edgeThreshold: CGFloat = 52.0 * uiScale
        let isLeft = localLocation.x <= edgeThreshold
        let isRight = localLocation.x >= (screenW - edgeThreshold)
        
        if isLeft {
            if currentPage.wrappedValue > 0 { startEdgePaging(direction: -1, screenW: screenW, currentPage: currentPage, viewModel: viewModel) }
            else { cancelEdgePaging() }
        } else if isRight {
            let canTurnToExistingNext = currentPage.wrappedValue < viewModel.totalPages() - 1
            let canExpandNewPage = (currentPage.wrappedValue == viewModel.totalPages() - 1) && !viewModel.isPageEmpty(currentPage.wrappedValue)
            if canTurnToExistingNext || canExpandNewPage { startEdgePaging(direction: 1, screenW: screenW, currentPage: currentPage, viewModel: viewModel) }
            else { cancelEdgePaging() }
        } else {
            cancelEdgePaging()
        }
    }
    
    private func startEdgePaging(direction: Int, screenW: CGFloat, currentPage: Binding<Int>, viewModel: HomeScreenViewModel) {
        if currentEdgeDirection == direction && edgePagingTask != nil { return }
        cancelEdgePaging()
        currentEdgeDirection = direction
        
        edgePagingTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 220_000_000)
            while !Task.isCancelled {
                guard let dir = currentEdgeDirection else { break }
                let edgeThreshold: CGFloat = 52.0 * uiScale
                let stillIn = (dir < 0) ? (lastTouchLocation.x <= edgeThreshold) : (lastTouchLocation.x >= (screenW - edgeThreshold))
                guard stillIn else { break }
                
                if dir < 0 {
                    if currentPage.wrappedValue > 0 {
                        impactFeedback.impactOccurred()
                        isPagingAnimating = true
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) { currentPage.wrappedValue -= 1 }
                        try? await Task.sleep(nanoseconds: 360_000_000)
                        isPagingAnimating = false
                    } else { break }
                } else if dir > 0 {
                    if currentPage.wrappedValue < viewModel.totalPages() - 1 {
                        impactFeedback.impactOccurred()
                        isPagingAnimating = true
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) { currentPage.wrappedValue += 1 }
                        try? await Task.sleep(nanoseconds: 360_000_000)
                        isPagingAnimating = false
                    } else if currentPage.wrappedValue == viewModel.totalPages() - 1 {
                        if !viewModel.isPageEmpty(currentPage.wrappedValue) {
                            impactFeedback.impactOccurred()
                            isPagingAnimating = true
                            viewModel.triggerExpandNewPage()
                            try? await Task.sleep(nanoseconds: 45_000_000)
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) { currentPage.wrappedValue += 1 }
                            try? await Task.sleep(nanoseconds: 360_000_000)
                            isPagingAnimating = false
                            break
                        } else { break }
                    }
                }
                try? await Task.sleep(nanoseconds: 280_000_000)
                guard !Task.isCancelled else { break }
            }
            currentEdgeDirection = nil
            edgePagingTask = nil
        }
    }
    
    func cancelEdgePaging() {
        currentEdgeDirection = nil
        edgePagingTask?.cancel()
        edgePagingTask = nil
    }
    
    func handleDockRealtimeSwap(
        localLocation: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        viewModel: HomeScreenViewModel
    ) {
        guard viewModel.isEditing else { return }
        guard let source = activeDragSource, case .dock(let currentIdx) = source else { return }
        guard localLocation.y >= (screenH - dockTriggerH) else { return }
        
        let dockMargin: CGFloat = 13.0 * uiScale
        let dockW = max(screenW - (dockMargin * 2.0), 1)
        let itemW = dockW / 4.0
        let dockCount = viewModel.dockApps.count
        guard dockCount > 1 else { return }
        
        let totalW = CGFloat(dockCount) * itemW
        let startX = (screenW - totalW) / 2.0
        let currentCenterX = startX + (CGFloat(currentIdx) + 0.5) * itemW
        
        if localLocation.x > currentCenterX + itemW * 0.65 && currentIdx < dockCount - 1 {
            let nextIdx = currentIdx + 1
            lightImpact.impactOccurred()
            withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                viewModel.moveItem(from: .dock(currentIdx), to: .dock(nextIdx))
                activeDragSource = .dock(nextIdx)
            }
        } else if localLocation.x < currentCenterX - itemW * 0.65 && currentIdx > 0 {
            let prevIdx = currentIdx - 1
            lightImpact.impactOccurred()
            withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                viewModel.moveItem(from: .dock(currentIdx), to: .dock(prevIdx))
                activeDragSource = .dock(prevIdx)
            }
        }
    }
    
    func finishDrag(
        globalPos: CGPoint,
        rootOrigin: CGPoint,
        screenW: CGFloat,
        screenH: CGFloat,
        dockTriggerH: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat,
        currentPage: Binding<Int>,
        viewModel: HomeScreenViewModel
    ) {
        cancelEdgePaging()
        guard let source = activeDragSource else { reset(); return }
        let local = CGPoint(x: globalPos.x - rootOrigin.x, y: globalPos.y - rootOrigin.y)
        
        let destination: AppLocation
        if local.y >= (screenH - dockTriggerH) {
            let dockMargin: CGFloat = 13.0 * uiScale
            let dockW = max(screenW - (dockMargin * 2.0), 1)
            let itemW = dockW / 4.0
            let dockCount = viewModel.dockApps.count
            let totalW = CGFloat(dockCount) * itemW
            let startX = (screenW - totalW) / 2.0
            
            let rawIdx = Int((local.x - startX) / itemW)
            var targetDock = min(max(0, rawIdx), min(dockCount, 3))
            
            if case .dock(let fromDock) = source {
                let fromCenterX = startX + (CGFloat(fromDock) + 0.5) * itemW
                if abs(local.x - fromCenterX) < itemW * 0.65 { targetDock = fromDock }
            }
            destination = .dock(targetDock)
        } else {
            let usableW = max(screenW - (48.0 * uiScale), 1)
            let colW = usableW / 4.0
            let col = min(max(0, Int((local.x - (24.0 * uiScale)) / colW)), 3)
            let targetRow = min(max(0, Int((local.y - headerH) / rowPitch)), 5)
            let targetGrid = currentPage.wrappedValue * viewModel.pageSize + targetRow * 4 + col
            destination = .grid(targetGrid)
        }
        
        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
            viewModel.moveItem(from: source, to: destination)
            viewModel.compactPages()
            currentPage.wrappedValue = min(currentPage.wrappedValue, max(0, viewModel.totalPages() - 1))
        }
        
        var noAnimationTrans = Transaction()
        noAnimationTrans.animation = nil
        withTransaction(noAnimationTrans) { reset() }
    }
}

// 📄 小组件拖拽协同器
@MainActor
final class WidgetDragCoordinator: ObservableObject {
    @Published var activeWidgetId: String? = nil
    let positionTracker = DragPositionTracker()
    var initialOriginY: CGFloat = 0
    var initialOriginX: CGFloat = 0
    var lastTouchLocation: CGPoint = .zero
    
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    
    func start(widgetId: String, originX: CGFloat, originY: CGFloat) {
        self.activeWidgetId = widgetId
        self.initialOriginX = originX
        self.initialOriginY = originY
        self.positionTracker.offset = .zero
    }
    
    func update(translation: CGSize) {
        self.positionTracker.offset = translation
    }
    
    func reset() {
        self.activeWidgetId = nil
        self.positionTracker.offset = .zero
        self.initialOriginX = 0
        self.initialOriginY = 0
        self.lastTouchLocation = .zero
    }
    
    func finishWidgetDrag(widgetDef: WidgetDefinition, screenW: CGFloat, rowPitch: CGFloat, currentPage: Binding<Int>, viewModel: HomeScreenViewModel) {
        impactFeedback.impactOccurred()
        let mgr = widgetDef.manager
        let finalY = max(0, initialOriginY + positionTracker.offset.height)
        let finalX = max(0, initialOriginX + positionTracker.offset.width)
        let halfWidth = max(0, (screenW - (48.0 * uiScale) - (18.0 * uiScale)) / 2.0)
        let maxRow = max(0, 6 - widgetDef.sizeRows)
        let targetRow = min(max(0, Int(round(finalY / rowPitch))), maxRow)
        let targetCol = (widgetDef.sizeCols < 4) ? ((finalX > (halfWidth / 2.0)) ? 2 : 0) : 0
        
        var noAnimationTrans = Transaction()
        noAnimationTrans.animation = nil
        withTransaction(noAnimationTrans) {
            reset()
            mgr.widgetPage = currentPage.wrappedValue
            mgr.widgetRow = targetRow
            mgr.widgetCol = targetCol
            viewModel.resolveAllWidgetOverlaps(priority: mgr)
        }
        
        withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
            viewModel.compactPages()
            currentPage.wrappedValue = min(currentPage.wrappedValue, max(0, viewModel.totalPages() - 1))
        }
    }
}
